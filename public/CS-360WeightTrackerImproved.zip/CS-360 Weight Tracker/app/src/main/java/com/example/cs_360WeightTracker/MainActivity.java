package com.example.cs_360WeightTracker;

// Author: Benjamin Sturgeon CS-360

// Necessary imports for Android functionality
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;


import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;

import com.example.cs_360WeightTracker.ChangeActivites.SetGoalWeightDialogFragment;
import com.example.cs_360WeightTracker.SMS.SMSPermissionDialogMessagePrompt;
import com.example.cs_360WeightTracker.databases.creator.WeightTrackerDatabaseCreator;
import com.example.cs_360WeightTracker.databases.commands.userAccounts;
import com.example.cs_360WeightTracker.databases.security.HashSaltSecurity;

// MainActivity class implementing necessary interfaces for various functionalities
public class MainActivity extends AppCompatActivity implements TextWatcher,
        SetGoalWeightDialogFragment.OnSetGoalWeightListener,
        SMSPermissionDialogMessagePrompt.OnSendSMSPermissionRationaleDialogResultListener {

    private static final int SEND_SMS_REQUEST_CODE = 0; // Request code for SMS permission
    // Additional fields for user notifications
    private static final String NOTIFICATION_CHANNEL_ID = "weight_tracker_alerts";
    private static final int NOTIFICATION_ID = 1;

    // Necessary fields for user authentication and UI components
    private String userSession = null; // Stores the username of the logged-in user
    private EditText userNameTextEditor; // Input field for username
    private EditText passwordTextEditor; // Input field for password
    private TextView errorMessageView; // Displays error messages
    private WeightTrackerDatabaseCreator userDatabase; // Database instance for managing user data

    /**
     * Validates username and password for new account creation
     */
    private boolean isNewAccountValid(String user, String pass) {
        if (user.trim().isEmpty() || pass.trim().isEmpty()) {
            return false;
        }
        return userDatabase.accountDao().getPassword(user) == null;
    }

    /**
     * Validates login credentials based on stored database values
     */
    private boolean isLoginValid(String user, String pass) {
        String hashForDatabase = userDatabase.accountDao().getPassword(user);
        byte[] saltForDatabase = userDatabase.accountDao().getSalt(user);

        return (hashForDatabase != null && saltForDatabase != null) &&
                hashForDatabase.equals(HashSaltSecurity.getHash(pass, saltForDatabase));
    }

    /**
     * Handles SMS permission logic before sending messages and triggers a local notification.
     */
    private boolean hasSendSMSPermissions() {
        String sendSMSPermission = Manifest.permission.SEND_SMS;

        if (checkSelfPermission(sendSMSPermission) != PackageManager.PERMISSION_GRANTED) {
            FragmentManager manager = getSupportFragmentManager();

            if (shouldShowRequestPermissionRationale(sendSMSPermission)) {
                new SMSPermissionDialogMessagePrompt().show(manager, "SMSPermissionDialog");
            } else {
                requestPermissions(new String[]{sendSMSPermission}, SEND_SMS_REQUEST_CODE);
            }
            // Trigger local notification
            showNotification("SMS Permission Needed", "Please grant permission for SMS notifications.");
            return false;
        }
        return true;
    }

    /**
     * Handles login navigation logic
     */
    private void proceedToWeightTracker() {
        Intent intent = new Intent(this, WeightTracker.class);
        intent.putExtra("username", userSession);
        startActivity(intent);
    }

    private void showNotification(String title, String message) {
        createNotificationChannel();

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(NOTIFICATION_ID, builder.build());
    }

    /**
     * Creates a notification channel for Android 8.0+ devices.
     */
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Weight Tracker Alerts";
            String description = "Notifications for user alerts";
            int importance = NotificationManager.IMPORTANCE_HIGH;

            NotificationChannel channel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
    }


    /**
     * Handles activity creation and restores session if available
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Restore session state if available
        if (savedInstanceState != null) {
            userSession = savedInstanceState.getString("sessionToken");
        }
        if (userSession != null) {
            proceedToWeightTracker();
        }

        // Initialize UI components
        userNameTextEditor = findViewById(R.id.editUserNameText);
        errorMessageView = findViewById(R.id.loginActivityErrorTextView);
        passwordTextEditor = findViewById(R.id.editPasswordText);

        userNameTextEditor.addTextChangedListener(this);
        passwordTextEditor.addTextChangedListener(this);

        // Initialize the database
        userDatabase = WeightTrackerDatabaseCreator.getInstance(getApplicationContext());
    }

    /**
     * Handles saving instance state during activity lifecycle changes
     */
    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("sessionToken", userSession);
    }

    /**
     * Handles new account creation process
     */
    public void onButtonNewAccountClick(View view) {
        String newUsername = userNameTextEditor.getText().toString();
        String newPassword = passwordTextEditor.getText().toString();

        if (isNewAccountValid(newUsername, newPassword)) {
            byte[] salt = HashSaltSecurity.getSalt();
            String hash = HashSaltSecurity.getHash(newPassword, salt);

            userDatabase.accountDao().insertAccount(new userAccounts(newUsername, hash, salt));
            userSession = newUsername;

            new SetGoalWeightDialogFragment().show(getSupportFragmentManager(), "setGoalWeightDialog");
        } else {
            displayErrorMessage(R.string.error_text_new_account);
        }
    }

    /**
     * Handles user login process
     */
    public void onButtonLogInClick(View view) {
        String username = userNameTextEditor.getText().toString();
        String password = passwordTextEditor.getText().toString();

        if (isLoginValid(username, password)) {
            userSession = username;
            proceedToWeightTracker();
        } else {
            displayErrorMessage(R.string.error_text_log_in);
        }
    }

    /**
     * Displays error messages dynamically
     */
    private void displayErrorMessage(int errorMessageRes) {
        errorMessageView.setText(errorMessageRes);
        errorMessageView.setVisibility(View.VISIBLE);
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        if (errorMessageView.getVisibility() == View.VISIBLE) {
            errorMessageView.setText("");
            errorMessageView.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public void afterTextChanged(Editable s) {}

    /**
     * Handles goal weight setting
     */
    @Override
    public void onSetGoalWeight(float weight) {
        if (userSession == null) {
            throw new IllegalStateException("User session not found.");
        }

        userDatabase.accountDao().setGoalWeight(weight, userSession);

        if (hasSendSMSPermissions()) {
            proceedToWeightTracker();
        }
    }

    /**
     * Handles SMS permission dialog response
     */
    @Override
    public void onSMSPermissionDialogMessagePrompt(boolean result) {
        if (result) {
            requestPermissions(new String[]{Manifest.permission.SEND_SMS}, SEND_SMS_REQUEST_CODE);
        } else {
            proceedToWeightTracker();
        }
    }
}