package com.example.cs_360WeightTracker.SMS;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

import com.example.cs_360WeightTracker.R;

/**
 * A dialog fragment that prompts the user for SMS permission.
 * Displays a rationale message explaining why the app needs SMS permissions.
 */
public class SMSPermissionDialogMessagePrompt extends DialogFragment {

    /**
     * Interface for handling the result of the SMS permission dialog.
     */
    public interface OnSendSMSPermissionRationaleDialogResultListener {
        void onSMSPermissionDialogMessagePrompt(boolean result);
    }

    // Listener to handle user responses from the permission dialog.
    private SMSPermissionDialogMessagePrompt.OnSendSMSPermissionRationaleDialogResultListener mListener;

    /**
     * Creates the alert dialog for SMS permission rationale.
     * @param savedInstanceState The previously saved state of the fragment.
     * @return The constructed AlertDialog instance.
     */
    @NonNull
    @Override
    public AlertDialog onCreateDialog(Bundle savedInstanceState) {
        // Create a TextView to display the permission rationale message.
        final TextView textView = new TextView(getActivity());
        textView.setText(R.string.dialog_send_sms_permission_rationale_text);
        textView.setPadding(30, 10, 30, 10); // Apply padding to the text view.

        // Build and return an alert dialog with positive and negative action buttons.
        return new AlertDialog.Builder(getActivity())
                .setTitle(R.string.dialog_send_sms_permission_rationale_title)
                .setView(textView)
                .setPositiveButton(R.string.dialog_fragment_positive, new DialogInterface.OnClickListener() {
                    // User agrees to grant SMS permission.
                    public void onClick(DialogInterface dialog, int whichButton) {
                        mListener.onSMSPermissionDialogMessagePrompt(true);
                    }
                })
                .setNegativeButton(R.string.dialog_fragment_casual_negative, new DialogInterface.OnClickListener() {
                    // User declines SMS permission.
                    public void onClick(DialogInterface dialog, int whichButton) {
                        showConfirmationDialog(); // Ask user to confirm their choice
                    }
                })
                .create();
    }

    /**
     * Shows a confirmation dialog when the user denies SMS permissions.
     */
    private void showConfirmationDialog() {
        new AlertDialog.Builder(getActivity())
                .setTitle("Are You Sure?")
                .setMessage("Without SMS permissions, we won’t be able to send celebratory messages for your weight achievements. Do you want to proceed without it?")
                .setPositiveButton("Yes, proceed", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        mListener.onSMSPermissionDialogMessagePrompt(false);
                    }
                })
                .setNegativeButton("Go back", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        dialog.dismiss(); // Close the confirmation dialog
                    }
                })
                .show();
    }

    /**
     * Attaches the dialog fragment to the parent context.
     * Ensures that the calling component implements the listener interface.
     * @param context The calling context (must implement OnSendSMSPermissionRationaleDialogResultListener).
     */
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (SMSPermissionDialogMessagePrompt.OnSendSMSPermissionRationaleDialogResultListener) context;
    }
}