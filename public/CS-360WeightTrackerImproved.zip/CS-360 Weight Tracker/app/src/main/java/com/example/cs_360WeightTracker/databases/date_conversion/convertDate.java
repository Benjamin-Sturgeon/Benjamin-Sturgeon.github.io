package com.example.cs_360WeightTracker.databases.date_conversion;

import androidx.room.TypeConverter;

import java.util.Date;

//This is used to convert dates to desired format based on current time
public class convertDate {
    @TypeConverter
    public static Date toDate(Long dateLong){
        return dateLong == null ? null: new Date(dateLong);
    }

    @TypeConverter
    public static long fromDate(Date date){
        return date == null ? null :date.getTime();
    }
}
