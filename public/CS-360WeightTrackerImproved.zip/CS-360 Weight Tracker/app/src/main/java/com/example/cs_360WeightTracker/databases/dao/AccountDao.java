package com.example.cs_360WeightTracker.databases.dao;

import androidx.annotation.Nullable;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.cs_360WeightTracker.databases.commands.userAccounts;

@Dao
public interface AccountDao {
    @Query("SELECT password FROM accounts WHERE username = :username")
    public @Nullable String getPassword(String username);

    @Query("SELECT salt FROM accounts WHERE username = :username")
    public @Nullable byte [] getSalt(String username);

    @Query("SELECT goal_weight FROM accounts WHERE username = :username")
    public float getGoalWeight(String username);

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    public void insertAccount(userAccounts userAccounts);

    @Query("UPDATE accounts SET goal_weight = :goalWeight WHERE username = :username")
    public void setGoalWeight(float goalWeight, String username);

    @Query("DELETE FROM accounts WHERE username = :username")
    void deleteAccountByUsername(String username);

}
