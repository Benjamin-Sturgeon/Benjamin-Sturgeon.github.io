package com.example.cs_360WeightTracker;
// Author: Benjamin Sturgeon CS-360

// Import necessary Android libraries for UI, database, and system interactions
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;


import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import java.util.Locale;


// Import custom components for weight tracking dialogs and database handling
import com.example.cs_360WeightTracker.ChangeActivites.AddWeightDialogFragment;
import com.example.cs_360WeightTracker.ChangeActivites.EditWeightDialogFragment;
import com.example.cs_360WeightTracker.databases.creator.WeightTrackerDatabaseCreator;
import com.example.cs_360WeightTracker.databases.commands.userWeights;

import java.util.List;
import java.util.Locale;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

// Class for managing weight tracking, database operations, and user interactions
public class WeightTracker extends AppCompatActivity
        implements EditWeightDialogFragment.OnEditWeightListener,
        AddWeightDialogFragment.OnAddWeightListener {

    private static final String NOTIFICATION_CHANNEL_ID = "weight_tracker_goals";
    private static final int NOTIFICATION_ID = 1;


    // Stores the currently logged-in user's username
    private String dataUsername = null;

    // Stores the selected weight entry from the list
    private userWeights currentWeight = null;

    // Position of selected weight entry in RecyclerView, initialized as no selection
    private int weightPosition = RecyclerView.NO_POSITION;

    // Action mode for handling UI interactions such as deleting and editing weights
    private ActionMode mode_Action = null;

    // Database instance for managing weight tracking data
    private WeightTrackerDatabaseCreator dataDatabase = null;

    // RecyclerView for displaying the list of recorded weights
    private RecyclerView weightsRecyclerView = null;

    // Adapter for managing RecyclerView's weight entries efficiently
    private WeightAdapter adapterWeights = null;

    // Stores the user's target weight for tracking progress
    private float weightGoal = 0.f;

    // Retrieves the list of weight entries associated with the user
    private List<userWeights> getWeights() {
        return dataDatabase.weightDao().getWeights(dataUsername);
    }

    // Called during the creation of the activity, responsible for setting up UI and restoring saved state
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_tracking);  // Set the layout file for the activity

        // Find UI elements
        TextView weightTitleTextView = findViewById(R.id.weightTitleTextView);
        View weightListTitles = findViewById(R.id.weight_list_titles);
        View listRecyclerView = findViewById(R.id.listRecyclerView);

        // Load animation
        Animation fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in);

        // Apply animation to UI elements
        weightTitleTextView.startAnimation(fadeIn);
        weightListTitles.startAnimation(fadeIn);
        listRecyclerView.startAnimation(fadeIn);


        // Restore previously saved instance state if available
        if (savedInstanceState != null) {
            dataUsername = savedInstanceState.getString("username");
            weightPosition = savedInstanceState.getInt("selectedWeightPosition");
        }

        // Retrieve username from the intent data passed from the previous activity
        Intent intent = getIntent();
        dataUsername = intent.getStringExtra("username");

        // Initialize the database instance for retrieving and storing weight data
        dataDatabase = WeightTrackerDatabaseCreator.getInstance(getApplicationContext());

        // Locate the RecyclerView in the layout
        weightsRecyclerView = findViewById(R.id.listRecyclerView);

        // Set up RecyclerView with a linear layout manager for vertical scrolling
        RecyclerView.LayoutManager mLinearLayoutManager = new LinearLayoutManager(getApplicationContext());
        weightsRecyclerView.setLayoutManager(mLinearLayoutManager);

        // Create an adapter with the user's weight entries and assign it to the RecyclerView
        adapterWeights = new WeightAdapter(getWeights());
        weightsRecyclerView.setAdapter(adapterWeights);

        // Retrieve the user’s goal weight from the database for tracking progress
        weightGoal = dataDatabase.accountDao().getGoalWeight(dataUsername);
    }

    // Method triggered when "Delete Account" button is clicked
    public void onDeleteAccountClick(View view) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Account")
                .setMessage("Are you sure you want to permanently delete your account?")
                .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteUserAccount(); // Call method to delete account
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // Deletes user account and redirects to MainActivity
    private void deleteUserAccount() {
        String username = getIntent().getStringExtra("username"); // Get current username

        // Delete user from database
        WeightTrackerDatabaseCreator database = WeightTrackerDatabaseCreator.getInstance(getApplicationContext());

        // Delete user weights first (to maintain integrity)
        database.weightDao().deleteUserWeights(username);

        // Then delete the user account
        database.accountDao().deleteAccountByUsername(username);


        // Clear session & redirect to login screen
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish(); // Close current activity
    }


    // Saves important data before the activity is destroyed to restore it later
    @Override
    public void onSaveInstanceState(@NonNull Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putString("username", dataUsername);  // Save the username
        savedInstanceState.putInt("selectedWeightPosition", weightPosition);  // Save selected weight position in RecyclerView
    }

    // Handles button click for adding a new weight entry
    public void onButtonAddWeightClick(View view) {
        // Ensure any existing action mode is finished before proceeding
        if (mode_Action != null) {
            mode_Action.finish();
            mode_Action = null;
        }

        // Open the Add Weight dialog fragment for user input
        FragmentManager manager = getSupportFragmentManager();
        AddWeightDialogFragment dialog = new AddWeightDialogFragment();
        dialog.show(manager, "addWeightDialog");
    }

    /**
     * Adds a weight entry to the database and updates the UI.
     * Triggers an SMS and a popup notification when the goal weight is reached.
     */
    @Override
    public void onWeightAdd(float newWeight) {
        String sendSMSPermission = Manifest.permission.SEND_SMS;

        // Create a new weight object linked to the current user
        userWeights weight = new userWeights(newWeight, dataUsername);

        // Insert the new weight entry into the database
        dataDatabase.weightDao().insertWeight(weight);

        // Add the weight entry to RecyclerView via adapter
        adapterWeights.addWeight(weight);

        // Check if user has reached their goal weight
        if (weight != null && weight.getWeight() <= weightGoal) {
            sendGoalNotifications(); // Trigger both SMS and popup notification
        }
    }

    /**
     * Updates the selected weight entry in the database and UI.
     * Triggers an SMS and a popup notification when the goal weight is reached.
     */
    @Override
    public void onWeightEdit(float newWeight) {
        String sendSMSPermission = Manifest.permission.SEND_SMS;

        // Ensure a valid weight entry is selected
        if (weightPosition == RecyclerView.NO_POSITION) {
            throw new RuntimeException();
        } else if (currentWeight == null) {
            currentWeight = getWeights().get(weightPosition);
        }

        // Update weight in the database and UI
        currentWeight.setWeight(newWeight);
        dataDatabase.weightDao().updateWeight(currentWeight);
        adapterWeights.editWeight(weightPosition, currentWeight);

        // Check if user has reached their goal weight
        if (newWeight <= weightGoal) {
            sendGoalNotifications(); // Trigger both SMS and popup notification
        }

        // Reset selection state for future operations
        currentWeight = null;
        weightPosition = RecyclerView.NO_POSITION;
    }

    /**
     * Sends both SMS and local popup notifications when the goal weight is reached.
     */
    private void sendGoalNotifications() {
        String sendSMSPermission = Manifest.permission.SEND_SMS;

        // SMS Notification (if permission is granted)
        if (checkSelfPermission(sendSMSPermission) == PackageManager.PERMISSION_GRANTED) {
            String notificationNumber = getString(R.string.default_phone_number);
            String smsMessage = String.format(Locale.ENGLISH,
                    "Congratulations! You reached your goal weight at %f Lbs!", weightGoal);

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(notificationNumber, null, smsMessage, null, null);
        }

        // Popup Notification
        showNotification("Goal Achieved!", "Congratulations! You've reached your weight goal of " + weightGoal + " lbs!");
    }

    /**
     * Displays a local popup notification.
     */
    private void showNotification(String title, String message) {
        createNotificationChannel();

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(NOTIFICATION_ID, builder.build());
    }

    /**
     * Creates a notification channel for Android 8.0+ devices.
     */
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Weight Tracker Alerts";
            String description = "Notifications for user weight achievements";
            int importance = NotificationManager.IMPORTANCE_HIGH;

            NotificationChannel channel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
    }


    // Handles actions when a user selects a weight entry from the RecyclerView
    private ActionMode.Callback userActionModeCallback = new ActionMode.Callback() {
        private boolean dialogCreated = false;

        // Handles deselection of a weight entry when needed
        public void itemDeselector() {
            int oldPos = weightPosition;
            currentWeight = null;
            weightPosition = RecyclerView.NO_POSITION;
            adapterWeights.notifyItemChanged(oldPos);
        }

        // Displays a context menu when a weight entry is selected
        @Override
        public boolean onCreateActionMode(ActionMode actionMode, Menu menu) {
            MenuInflater inflater = actionMode.getMenuInflater();
            inflater.inflate(R.menu.context_menu, menu);
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode actionMode, Menu menu) {
            return false;
        }

        // Handles actions when items in the context menu are pressed
        @Override
        public boolean onActionItemClicked(ActionMode actionMode, MenuItem menuItem) {
            switch (menuItem.getItemId()) {
                case R.id.deleteWeight:
                    dataDatabase.weightDao().deleteWeight(currentWeight);
                    adapterWeights.removeWeight(weightPosition);
                    actionMode.finish();
                    return true;

                case R.id.editWeight:
                    FragmentManager manager = getSupportFragmentManager();
                    EditWeightDialogFragment dialog = new EditWeightDialogFragment();
                    dialog.show(manager, "editWeightDialog");
                    dialogCreated = true;
                    actionMode.finish();
                    return true;

                default:
                    return false;
            }
        }

        @Override
        public void onDestroyActionMode(ActionMode actionMode) {
            if (!dialogCreated) {
                itemDeselector();
            }
            mode_Action = null;
        }
    };
    //This class is used for view management
    private class weightViewContainer extends RecyclerView.ViewHolder
                            implements View.OnClickListener {
        TextView mTextViewWeightDate = null;
        TextView mTextViewWeightValue = null;

        userWeights mWeight = null;

        public weightViewContainer(LayoutInflater layoutInflater, ViewGroup parent){
            super(layoutInflater.inflate(R.layout.recycler_view_items,parent, false));

            itemView.setOnClickListener(this);

            mTextViewWeightDate = itemView.findViewById(R.id.textViewWeightDate);
            mTextViewWeightValue = itemView.findViewById(R.id.textViewWeightValue);
        }

        public void bindWeight(userWeights weight, int position) {
            mWeight = weight;

            mTextViewWeightDate.setText(String.format("%tD", mWeight.getDateTime()));
            mTextViewWeightValue.setText(String.format("%f Lbs", mWeight.getWeight()));

            if(weightPosition == position) {
                mTextViewWeightValue.getRootView().setBackgroundColor(getResources().getColor(R.color.teal_200, getTheme()));
            } else {
                mTextViewWeightValue.getRootView().setBackgroundColor(Color.TRANSPARENT);
            }
        }

        @Override
        public void onClick(View view) {
            if (mode_Action != null) {
                mode_Action.finish();
                mode_Action = null;
            }

            currentWeight = mWeight;
            weightPosition = getAdapterPosition();

            adapterWeights.notifyItemChanged(weightPosition);

            mode_Action = WeightTracker.this.startActionMode(userActionModeCallback);
        }
    }

    // This is the WeightAdapter class for the RecyclerView, responsible for displaying and managing weight entries.
    private class WeightAdapter extends RecyclerView.Adapter<weightViewContainer> {
        private List<userWeights> mWeights;  // List holding all weight entries for the user

        // Constructor for initializing the adapter with a list of weight entries
        public WeightAdapter(List<userWeights> weights) {
            mWeights = weights;
        }

        // Removes a weight entry from the list at the given position
        public void removeWeight(int position) {
            mWeights.remove(position);  // Remove weight entry from the list
            notifyItemRemoved(position);  // Notify RecyclerView that an item has been removed
        }

        // Adds a new weight entry to the top of the list and scrolls to it automatically
        public void addWeight(userWeights weight) {
            mWeights.add(0, weight);  // Insert the new weight entry at the beginning of the list
            notifyItemInserted(0);  // Notify RecyclerView that a new item has been added

            weightsRecyclerView.scrollToPosition(0);  // Scroll to the newly added weight entry
        }

        // Updates an existing weight entry in the list with a new value
        public void editWeight(int position, userWeights newWeight) {
            mWeights.set(position, newWeight);  // Replace the existing weight entry with the new value
            notifyItemChanged(position);  // Notify RecyclerView that an item has been updated
        }

        // Creates a new ViewHolder for the RecyclerView items when needed
        @NonNull
        @Override
        public weightViewContainer onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getApplicationContext());  // Get the layout inflater for creating item views
            return new weightViewContainer(layoutInflater, parent);  // Create and return a new ViewHolder instance
        }

        // Binds weight data to a ViewHolder for display in the RecyclerView
        @Override
        public void onBindViewHolder(@NonNull weightViewContainer holder, int position) {
            holder.bindWeight(mWeights.get(position), position);  // Pass weight entry data to ViewHolder for binding
        }

        // Returns the total number of weight entries stored in the list
        @Override
        public int getItemCount() {
            return mWeights.size();  // Return the size of the weight entry list
        }
    }
}